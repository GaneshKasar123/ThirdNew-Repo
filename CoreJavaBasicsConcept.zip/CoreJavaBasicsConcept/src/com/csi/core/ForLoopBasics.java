package com.csi.core;

public class ForLoopBasics {
	public static void main(String[] args) {

		int i;
		for (i = 1; i <= 10; i++) {
			System.out.println("CSI");
		}
	}
}
