package com.csi.core;

public class DoWhileConcept {
	public static void main(String[] args) {

		int age=55;
		do{
			System.out.println("ELIGIBLE FOR VACCINATION");
			
			break;
		}while(age>=45);
	}

}
