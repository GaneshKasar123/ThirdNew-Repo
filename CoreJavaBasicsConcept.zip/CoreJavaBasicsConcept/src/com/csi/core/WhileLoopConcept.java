package com.csi.core;

public class WhileLoopConcept {
	public static void main(String[] args) {

		int age=55;
		
		while(age>=18)
		{
			System.out.println("Eligible for vote");
			break;
			
		}
	}
}
